package com.app.controllers;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.xml.sax.InputSource;

import com.app.controller.DataAccesss;

@WebServlet("/upload")
public class UploadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   DiskFileItemFactory factory;
   ServletFileUpload uploadHandler;
   Map <String,String> formfields;
   int MAX_SIZE=3*1024;
   int FILE_SIZE=10*1024;
   DataAccesss access;	
    public UploadController() {
        super();
        
        factory = new DiskFileItemFactory();
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
        factory.setSizeThreshold(MAX_SIZE);
        
        
        uploadHandler = new  ServletFileUpload(factory);
        uploadHandler.setSizeMax(FILE_SIZE);
        
        formfields = new HashMap<String,String>();
        
        access= new DataAccesss();
        
    }


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String fileContent="";
		try{
		if(!uploadHandler.isMultipartContent(request)){
			
			
		}
		else{
			List<FileItem> files = uploadHandler.parseRequest(request);
			
			for(FileItem item :files){
				
				if(!item.isFormField()){
					
					 InputStream is = item.getInputStream();
					 while(true){
						 
						 int chr = is.read();
						 if(chr== -1){
							 break;
						 }
						 else{
							char ch = (char)chr;
							fileContent+=ch;
						 }
					 } 
					 
					
				}
				
				else{
					
					String fieldName=item.getFieldName(); 
					byte[] fieldData = item.get();
					String field=new String(fieldData);
					formfields.put(fieldName, field);
				}
			}
			
			
		}		
		writer.print(fileContent);
		writer.print(formfields);
		
		
		int x=access.insertRecord(formfields, fileContent);
		writer.print("Record inserted "+x);
		
		
		}
		catch(Exception exp){
			exp.printStackTrace();
		}
		
		
		
	}

}
