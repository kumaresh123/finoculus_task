package com.app.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DataAccesss {

	Connection connection;
	PreparedStatement sql1;
	PreparedStatement sql2;
	PreparedStatement sql3;
	ResultSet result;
	public DataAccesss() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
			sql1=connection.prepareStatement("insert into employee values(?,?,?,?)");
			sql2=connection.prepareStatement("insert into employee_details values(?,?)");
			sql3=connection.prepareStatement("select e.id,e.name,e.mobile,e.address , d.descr from employee e inner join employee_details d where e.id=d.id");
		}
		catch( Exception exp){
			
			exp.printStackTrace();
		}
	}
	
	
	public  int insertRecord(Map<String,String> fields, String content){
		int count=0;
		try{
			int id = Integer.parseInt(fields.get("id"));
			
			sql1.setInt(1, id);
			sql1.setString(2,fields.get("name"));
			sql1.setString(3,fields.get("mobile"));
			sql1.setString(4,fields.get("address"));
			
			count=sql1.executeUpdate();
			
			if(count==1){
				sql2.setInt(1,id);
				sql2.setString(2, content);
				count+=sql2.executeUpdate();
			}
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return count;
	}
	
	
	public List<String[]> getAllRecords(){
		List<String[]> data = new ArrayList<String[]>();
		try{
			 result=sql3.executeQuery();
			 while(result.next()){
				 
				 String[] record = new String[5];
				 record[0]=result.getString(1);
				 record[1]=result.getString(2);
				 record[2]=result.getString(3);
				 record[3]=result.getString(4);
				 record[4]=result.getString(5);
				 data.add(record);
			 }
			
		}
		catch(Exception exp){
			exp.printStackTrace();
		}
		return data;
	}
	
}
