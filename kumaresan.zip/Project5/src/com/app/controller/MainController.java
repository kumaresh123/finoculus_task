package com.app.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;


@WebServlet("/main")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	InitialContext context;
	DataSource source;
	Connection connection;

	public MainController() {
		super();
		try {
			context = new InitialContext();
			source = (DataSource) context.lookup("java:comp/env/datasource/mysql");
			connection = source.getConnection();

		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer;
		try {

			writer = response.getWriter();
			String d = connection.getMetaData().getDatabaseProductName();
			writer.print("connected to " + d);
			writer.close();
		} catch (Exception exp) {
			exp.printStackTrace();
		}

	}

}
